Anisa Johnny
IMD3901A Design Studio 3
Assignment 2: Multi-Platform Interactions
February 7th, 2023

1. Overview of what you did (i.e. what are the controls? Why this design?)

// Where I Started 
I started the assignment by focusing on a theme that I wanted for the WebVR application. Using one of the environment presets as inspiration, I chose to create a park with a forest background. In addition, I went through the example code from the lessons, used the A-Frame website with their documentations, and went on Sketchfab to gather assets for the design.

// What are the controls
I am using WASD controls for the user to move around the environment and the mouse/trackpad controls for looking around with the camera on a desktop. On mobile, the user would use motion sensors to see around the environment (tilting their phone and using their hands). For the objects, the user has the ability to hover over objects for the selection, release and manipulation. The user can also click on an object to lift it up and receive sound feedback (book).


2. What was challenging?
What was the most challenging aspect of this assignment was getting the add and remove virtual elements to work. I wanted to use a button so that the user can make a ball appear in the sandbox and click it again to remove it. However, after a couple hours, I was only able to get the ball to appear but was receiving errors when removing it. I tried using different functions such as removeEventListener and removeChildNode but nothing worked.

3. What went well (i.e. how did you solve the above challenges?)
Eventually, I was able to work out the challenge I was facing by looking over the custom component code used in class and released that I was most likely overthinking the concept. With this, I was able to get the ball to be added and removed from the scene once.


URL to Github repository:
https://github.com/nisaa1331/Multi-Platform-Interactions.git

Links to Assets:

Sandbox Asset
https://sketchfab.com/3d-models/sand-box-60c4d916d8974aeab4623c936694fad5

Sand Photo
https://www.freepik.com/free-photo/brown-background-natural-sand-texture_18998880.htm#query=sand&position=0&from_view=search&track=sph

Music
https://pixabay.com/sound-effects/search/park/?manual_search=1&order=None

https://pixabay.com/sound-effects/kids-playing-in-the-playground-with-birdsong-and-city-atmosphere-25838/

Playground Asset
https://sketchfab.com/3d-models/playground-draft-for-xyzschool-9f7ed590a116422aaaa64d6f9e88827a

