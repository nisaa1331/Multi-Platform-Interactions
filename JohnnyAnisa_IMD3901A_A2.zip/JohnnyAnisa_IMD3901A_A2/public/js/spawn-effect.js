'use script';

AFRAME.registerComponent('spawn-entity', {
  
    // Accept value for color or default to blue.
    schema: {
      color: {type: 'color', default: 'blue'}
    },
    multiple: false,
    init: function() {
      
      const self = this;
      self.isHere = false;
      
      self.box = document.createElement('a-sphere');
      self.box.setAttribute('material', 'color', self.data.color);


      // Add the click listener.
      self.el.addEventListener('click', function(e) {

        if (self.isHere == true) {
            console.log('box is now deleted');
            self.box.remove();
            self.isHere = false;

        }

        else {
            console.log('box is now added');
            self.box.setAttribute('position', '3.5 0.6 0');
            self.box.setAttribute('scale', '0.3 0.3 0.3');
            self.el.sceneEl.appendChild(self.box);
            self.isHere = true;
        }


     
  
        // Append the box element to the scene.
        
      });



      
    }
  });